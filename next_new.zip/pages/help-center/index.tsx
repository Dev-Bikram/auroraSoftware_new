



import Wrapper from "@/layout/wrapper/Wrapper";

import HelpCenter from "@/components/HelpCenter/HelpCenter";







export default function Home() {
  return (
    <Wrapper>
        <HelpCenter />
    </Wrapper>
  );
}
