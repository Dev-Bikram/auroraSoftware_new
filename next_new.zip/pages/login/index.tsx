


import Wrapper from "@/layout/wrapper/Wrapper";
import LoingMain from "@/components/LoingMain/LoingMain";







export default function index() {
  return (
    <Wrapper>
        <LoingMain />
    </Wrapper>
  );
}
