


import Wrapper from "@/layout/wrapper/Wrapper";
import ResetPassword from "@/components/ResetPassword/ResetPassword";







export default function index() {
  return (
    <Wrapper>
        <ResetPassword />
    </Wrapper>
  );
}
