const events = {
    showNotification: "showNotification",
    logoutCurrentUser: "logoutCurrentUser",
    routerPush: "routerPush",
    fetchAfterAddToFavourite:'fetchAfterAddToFavourite'
  };
  
  export default events;