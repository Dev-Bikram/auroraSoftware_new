export const MAX_SIZE_FILE=2000000;
