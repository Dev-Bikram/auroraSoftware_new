// eslint-disable-next-line import/no-extraneous-dependencies
import EventEmitter from "eventemitter3";

const eventEmitter = new EventEmitter();
export default eventEmitter;
