

# Pending work

1. Implement event emitter for toastify ( notistack ) with axios
2. implement event emitter for logout
3. implement remeber me for login
4. axiosInstance setup with error handling and token refresh functionality 
5. server side redux setup 


# Example project
1. Heap up
2. compsheet
