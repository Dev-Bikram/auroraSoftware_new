import React from 'react'

const SlickSliderWrapper = () => {
  return (
    <div>SlickSliderWrapper</div>
  )
}

export default SlickSliderWrapper