



import PrivacyPolicy from "@/components/PrivacyPolicy/PrivacyPolicy";
import Wrapper from "@/layout/wrapper/Wrapper";








export default function Home() {
  return (
    <Wrapper>
        <PrivacyPolicy />
    </Wrapper>
  );
}
