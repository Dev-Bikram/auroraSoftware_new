

import Wrapper from "@/layout/wrapper/Wrapper";
import ContactUs from "@/components/ContactUs/ContactUs";







export default function index() {
  return (
    <Wrapper>
        <ContactUs />
    </Wrapper>
  );
}
