



import Wrapper from "@/layout/wrapper/Wrapper";

import Faqs from "@/components/Faqs/Faqs";







export default function Home() {
  return (
    <Wrapper>
        <Faqs />
    </Wrapper>
  );
}
