
import Wrapper from "@/layout/wrapper/Wrapper";
import BlogMain from "@/components/BlogMain/BlogMain";







export default function index() {
  return (
    <Wrapper>
        <BlogMain/>
    </Wrapper>
  );
}
