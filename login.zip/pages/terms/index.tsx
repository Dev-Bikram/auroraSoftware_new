



import Terms from "@/components/Terms/Terms";
import Wrapper from "@/layout/wrapper/Wrapper";








export default function Home() {
  return (
    <Wrapper>
        <Terms />
    </Wrapper>
  );
}
